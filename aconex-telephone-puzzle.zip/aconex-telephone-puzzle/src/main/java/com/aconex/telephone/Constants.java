package com.aconex.telephone;

/**
 * Created by Sachin Maheshwari on 9/13/2015.
 */
public class Constants {
    public static final String DELIMITER = "-";
}
